package mx.uv.t4is.Dulceria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DulceriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
