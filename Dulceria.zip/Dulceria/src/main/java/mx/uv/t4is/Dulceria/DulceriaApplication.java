package mx.uv.t4is.Dulceria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DulceriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DulceriaApplication.class, args);
	}

}
